wiki_lang_id v1.0

This language identification dataset was used in the paper "On the Language-specificity of Multilingual BERT and the Impact of Fine-tuning".
See https://github.com/mtanti/mbert-language-specificity for more information.

It consists of 33 languages, each consisting of 5,000 paragraphs extracted from the 20210420 Wikimedia dump.
The ISO 639-1 language codes of the languages extracted are af, ar, bg, de, el, en, es, et, eu, fa, fi, fr, he, hi, hu, id, it, ja, kk,
ko, mr, nl, pt, ru, ta, te, th, tl, tr, ur, vi, yo, and zh.
The format of the dataset is two tab separated fields per line, with the first field containing the paragraph and the second field containing the language code.
